In data sender make sure that you select "Stype HF protocol" under the FPS dropdown list.
The best is to put the data sender on one PC/Laptop, and receive the data on your development PC, otherwise you may have issues if one locks the port so the other can't access it.

You can double check your parser with the sample data. Sometimes, because of environment settings in your PC data sender will not interpret comma as decimal sign, so it will send bigger values for numbers. So, if you receive 100 times bigger values then what you can see in XML, it means that the environment settings in windows are incorrect. So you can either change the settings, or just try to replace commas with dots in the XML file and see if that helps.
